#include "Panadero.h"
#include <iostream>
using namespace std;

Panadero::Panadero() {}

void Panadero::registrarReceta(vector<Receta>& recetas) {
    string nombre;
    cout << "Nombre de la receta: ";
    cin >> nombre;
    Receta r(nombre);

    int num;
    cout << "¿Cuántos ingredientes tendrá?: ";
    cin >> num;

    for (int i = 0; i < num; ++i) {
        string n, u;
        float c;
        cout << "Ingrediente " << i + 1 << " nombre: ";
        cin >> n;
        cout << "Unidad: ";
        cin >> u;
        cout << "Cantidad: ";
        cin >> c;
        r.agregarIngrediente(Ingrediente(n, u, c, 0));
    }
    recetas.push_back(r);
    cout << "Receta registrada con éxito.\n";
}

void Panadero::registrarPanes(InventarioPanes& inv, vector<Receta>& recetas) {
    if (recetas.empty()) {
        cout << "No hay recetas registradas.\n";
        return;
    }

    cout << "Recetas disponibles:\n";
    for (size_t i = 0; i < recetas.size(); ++i)
        cout << i + 1 << ". " << recetas[i].getNombre() << endl;

    int opcion;
    cout << "Seleccione una receta: ";
    cin >> opcion;
    if (opcion < 1 || opcion > (int)recetas.size()) return;

    int cantidad;
    cout << "Cantidad a producir: ";
    cin >> cantidad;

    Produccion produccion(recetas[opcion - 1], cantidad);
    produccion.registrarProduccion(inv);

    inv.registrarProducto(Producto(recetas[opcion - 1].getNombre(), cantidad));
    cout << "Producción registrada.\n";
}

void Panadero::consultarStock(const InventarioPanes& inv) {
    auto productos = inv.getProductos();
    cout << "\n--- Stock de productos ---\n";
    for (const auto& p : productos)
        cout << p.getTipo() << ": " << p.getCantidad() << " unidades\n";
}
