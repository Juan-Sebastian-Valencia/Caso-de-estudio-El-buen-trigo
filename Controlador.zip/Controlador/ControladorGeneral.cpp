#include "ControladorGeneral.h"
#include "Panadero.h"
#include "EncargadoInventario.h"
#include "Administrador.h"
#include <iostream>
using namespace std;

void ControladorGeneral::ejecutarMenuPanadero(Panadero* panadero) {
    recetas = Receta::cargarRecetas();

    int opcion;
    Panadero* p = dynamic_cast<Panadero*>(panadero);
    switch (opcion) {
        case 1: p->registrarReceta(recetas);
                if (!recetas.empty()) recetas[0].guardarRecetas(recetas);
                break;
        case 2: p->registrarProduccion(inventario, recetas); break;
        case 3: p->consultarStock(inventario); break;
        default: cout << "Opción inválida.\n"; break;
    }
    if (!recetas.empty()) recetas[0].guardarRecetas(recetas);
}

void ControladorGeneral::ejecutarMenuEncargadoInventario(EncargadoInventario* encargadoInventario) {
    inventario.cargarInventario();
    recetas = Receta::cargarRecetas();

    int opcion;
    EncargadoInventario* e = dynamic_cast<EncargadoInventario*>(encargadoInventario);
    switch (opcion) {
        case 1: e->registrarIngrediente(inventario); break;
        case 2: e->consultarInventario(inventario); break;
        case 3: e->verificarNivel(inventario); break;
        default: cout << "Opción inválida.\n"; break;
    }
    inventario.guardarInventario();
}

void ControladorGeneral::ejecutarMenuAdministrador(Administrador* administrador){
    int opcion;
    Administrador* a = dynamic_cast<Administrador*>(administrador);
    switch (opcion) {
        case 1: a->generarReporte(inventario); break;
        case 2: a->exportarReporteTxt(inventario); break;
        default: cout << "Opción inválida.\n"; break;
    }
}