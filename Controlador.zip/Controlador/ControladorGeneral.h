#ifndef CONTROLADORGENERAL_H
#define CONTROLADORGENERAL_H

#include <vector>
#include "Vista/Vista.h"
#include "Modelo/InventarioPanes.h"
#include "Modelo/InventarioIngredientes.h"
#include "Panadero.h"
#include "EncargadoInventario.h"
#include "Administrador.h"
#include "Modelo/Receta.h"

class ControladorGeneral {
private:
    Vista vista;
    InventarioPanes inventario;
    InventarioIngredientes inventarioIngredientes;
    std::vector<Receta> recetas;

public:
    void ejecutarMenuPanadero(Panadero* panadero);
    void ejecutarMenuEncargadoInventario(EncargadoInventario* encargadoInventario);
    void ejecutarMenuAdministrador(Administrador* administrador);
};

#endif
