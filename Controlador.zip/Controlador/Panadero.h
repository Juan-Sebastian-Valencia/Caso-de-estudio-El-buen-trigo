#ifndef PANADERO_H
#define PANADERO_H

#include "InventarioIngredientes.h"
#include "Receta.h"
#include "InventarioPanes.h"
#include <vector>

class Panadero {
public:
    Panadero();
    void registrarReceta(vector<Receta>& recetas);
    void modificarReceta();
    void registrarProduccion(InventarioPanes& inv, vector<Receta>& recetas);
    void consultarStock(const InventarioPanes& inv);
};

#endif
